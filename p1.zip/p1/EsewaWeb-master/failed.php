<?php
echo "<h1> Payment Failed";

?>
<a href="https://brp.com.np/esewa">Goto Homepage</a>