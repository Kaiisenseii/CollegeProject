# EsewaWeb
Esewa Web Payment Integration

# Currently It Consists of 3 things

1. FonePay: For Third Party payment to ESEWA 
2. EPay: For Web-Based Payment
3. SDK: For Android Application

![Image description](https://developer.esewa.com.np/_images/system_interaction.png)
Test is provided here
