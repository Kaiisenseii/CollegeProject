<?php 

// Change Info From Here

$epay_url = "https://uat.esewa.com.np/epay/main";
$pid = "ThuloTech9";
$successurl = "https://brp.com.np/esewa/success.php?q=su";
$failedurl = "https://brp.com.np/esewa/failed.php?q=fu";
$merchant_code = "epay_payment"; 
$fraudcheck_url = "https://uat.esewa.com.np/epay/transrec";

// For Amount Check
$actualamount = 1000;

?>