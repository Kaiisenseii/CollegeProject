<?php
  include 'admin/php_files/database.php';

  // $hostname = "http://localhost/shbs";
  $hostname = "http://localhost/p1";
    
?>